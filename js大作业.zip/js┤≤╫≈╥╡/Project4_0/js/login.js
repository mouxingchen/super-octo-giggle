window.addEventListener('load', function () {
    //1.移动窗口
    const moveWindow = function () {
        const move = document.querySelector('.head');
        const login = document.querySelector('.login-box');
        let mX = 0,
            mY = 0;

        move.addEventListener('mousedown', function (e) {
            mX = e.clientX - login.offsetLeft;
            mY = e.clientY - login.offsetTop;
            document.addEventListener('mousemove', fn);

            function fn(event) {
                login.style.left = event.clientX - mX + 'px';
                login.style.top = event.clientY - mY + 'px';
            }
            document.addEventListener('mouseup', function () {
                document.removeEventListener('mousemove', fn);
            })
        });
    }
    moveWindow()

    //2.表单焦点功能实现
    const formValidation = function () {
        const logbox = document.querySelectorAll('.login-input');
        const namebox = logbox[0];
        const accountbox = logbox[1];
        const passwordbox = logbox[2];
        const rePassbox = logbox[3];
        const submitbox = logbox[4];
        const foot = document.querySelector('.foot');
        let val = '';
        let flag = [false, false, false, false];
        //为每一个input添加事件对象（blur不冒泡所以无法用委托实现）
        namebox.lastElementChild.addEventListener('blur', function () {
            val = namebox.lastElementChild.value;
            if (checkRate(val)) {
                namebox.firstElementChild.style.opacity = '0';
                foot.textContent = '';
                flag[0] = true;
            } else {
                namebox.firstElementChild.style.opacity = '1';
                foot.textContent = '格式错误';
                flag[0] = false;
            }
        });
        accountbox.lastElementChild.addEventListener('blur', function () {
            val = accountbox.lastElementChild.value;
            if (checkRate(val)) {
                accountbox.firstElementChild.style.opacity = '0';
                foot.textContent = '';
                flag[1] = true;
            } else {
                accountbox.firstElementChild.style.opacity = '1';
                foot.textContent = '格式错误';
                flag[1] = false;
            }
        });
        passwordbox.lastElementChild.addEventListener('blur', function () {
            val = passwordbox.lastElementChild.value;
            if (checkRate(val)) {
                passwordbox.firstElementChild.style.opacity = '0';
                foot.textContent = '';
                flag[2] = true;
            } else {
                passwordbox.firstElementChild.style.opacity = '1';
                foot.textContent = '格式错误';
                flag[2] = false;
            }
        })
        rePassbox.lastElementChild.addEventListener('blur', function () {
            let rePass = passwordbox.lastElementChild.value;
            val = this.value;
            if (rePass === val && (val.length >= 6 && val.length <= 12)) {
                rePassbox.firstElementChild.style.opacity = '0';
                foot.textContent = '';
                flag[3] = true;
            } else {
                rePassbox.firstElementChild.style.opacity = '1';
                foot.textContent = '两次输入的密码不一致 请重新输入';
                flag[3] = false;
            }
        });
        submitbox.addEventListener('click', function (e) {
            e.preventDefault();
            if (checkAllpass(flag)) {
                sessionStorage.setItem('name', namebox.lastElementChild.value);
                location.href = 'welcome.html';
            } else {
                foot.textContent = '格式错误 提交失败';
            }
        })
        //判断是否为纯英文和数字
        function checkRate(nubmer) {
            var re = /^[0-9a-zA-Z]*$/g; //判断字符串是否为数字和字母组合     //判断正整数 /^[1-9]+[0-9]*]*$/  
            if (!re.test(nubmer)) {
                return false;
            } else {
                return true;
            }
        }

        function checkAllpass(flags) {
            for (let value of flags) {
                if (!value) return false;
            }
            return true;
        }
    }
    formValidation()

    // 3.切换注册和登录菜单
    const reg_logLink = function () {
        const log_form = document.querySelector('.log_form')
        const reg_form = document.querySelector('.reg_form')
        const title = document.querySelector('.title')
        const reg_link = document.querySelector('.reg_link')
        const log_link = document.querySelector('.log_link')


        reg_link.addEventListener('click', (e) => {
            e.preventDefault()
            log_form.classList.remove('flex')
            reg_form.classList.add('flex')
            title.textContent = '注册账号'
        })

        log_link.addEventListener('click', (e) => {
            e.preventDefault()
            reg_form.classList.remove('flex')
            log_form.classList.add('flex')
            title.textContent = '登录账号'
        })
    }
    reg_logLink()


    const interactive = function () {
        const regForm = document.querySelector('.reg_form')
        const logForm = document.querySelector('.log_form')

        logForm.addEventListener('submit', (e) => {

            const username = document.querySelector('#username').value
            const password = document.querySelector('#password').value

            e.preventDefault()
            data = {
                username,
                password
            }
            console.log(data);
        })

          // 监听注册表单的提交事件
          regForm.addEventListener('submit',(e)=>{
            e.preventDefault();
            const username = document.querySelector('#username').value
            const password = document.querySelector('#password').value
            let data={
                username,
                password
            }
            $post('/api/reguster',data,(res)=>{
                if(res.status!==0){
                    alert(res.messages)``
                }
                    alert('注册成功！')
            })
          })

          logForm.addEventListener('submit',(e)=>{
            e.preventDefault()
          })

        console.log('7777');
    }
    interactive()

    // $(function() {

    //     $('.reg_form').on('submit', function(e) {
    //       // 1. 阻止默认的提交行为
    //       e.preventDefault()
    //       // 2. 发起Ajax的POST请求
    //       var data = {

    //       }
    //       $.post('/api/reguser', data, function(res) {
    //         if (res.status !== 0) {
    //           return layer.msg(res.message)
    //         }
    //         layer.msg('注册成功，请登录！')
    //         // 模拟人的点击行为
    //         $('#link_login').click()
    //       })
    //       console.log(data);
    //     })

    //     // 监听登录表单的提交事件
    //     $('.log_form').submit(function(e) {
    //       // 阻止默认提交行为
    //       e.preventDefault()
    //       $.ajax({
    //         url: '/api/login',
    //         method: 'POST',
    //         // 快速获取表单中的数据
    //         data: $(this).serialize(),
    //         success: function(res) {
    //           if (res.status !== 0) {
    //             return layer.msg('登录失败！')
    //           }
    //           layer.msg('登录成功！')
    //           // 将登录成功得到的 token 字符串，保存到 localStorage 中
    //           localStorage.setItem('token', res.token)
    //           // 跳转到后台主页
    //           location.href = '/index.html'
    //         }
    //       })
    //     })
    //   })

});