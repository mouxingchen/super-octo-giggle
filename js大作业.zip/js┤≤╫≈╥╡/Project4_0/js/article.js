window.addEventListener('load', function () {
    //增删评论功能实现
    const comment = document.querySelector('.comment');
    const commentbox = document.querySelectorAll('.comment-box');
    const stuff = document.querySelectorAll('.comment-stuff');
    let textarea = document.querySelector('textarea');
    const button = document.querySelector('button');
    let index = 0;
    let val = '';
    const month = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

    //头像
    const ul = document.querySelector('.lt-imgbox>ul');
    const lis = ul.children;
    let id = 0;
    for (let i = 0; i < lis.length; i++) {
        lis[i].addEventListener('click', function () {
            for (let li of lis) {
                li.classList = '';
            }
            this.classList.add('choose');
            id = i;
        });
    }

    button.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        val = textarea.value;
        if (val.length < 5) {
            alert('留言字数请不少于5哦');
        } else {
            if (sessionStorage.getItem('name')) {
                let div = document.createElement('div');
                let attr = document.createAttribute('class');
                let date = new Date();
                attr.value = 'comment-box';
                div.setAttributeNode(attr);
                div.innerHTML = `
                <div class="comment-area">
                    <div class="com-img"><img src="${lis[id].firstElementChild.getAttribute('src')}" alt=""></div>
                    <div class="com-text">
                        <h3>${sessionStorage.getItem('name')}</h3>
                        <p>${val}</p>
                        <div class="com-date">${date.getDate()} ${month[date.getMonth() + 1]} ${date.getFullYear()}</div>
                    </div>
                </div>
                <div class="comment-stuff">[删除]</div>`;
                comment.appendChild(div);
                div.lastElementChild.addEventListener('click', function () {
                    if (confirm('确定要删除留言吗？')) {
                        this.parentElement.removeAttribute('class');
                        this.parentElement.parentElement.removeChild(this.parentElement);
                    }
                });
                textarea.value = '';
            } else {
                alert('请先登录');
                location.href = 'login.html';
            }
        }
    });

    while (index < 3) {
        stuff[index].addEventListener('click', function () {
            alert('只能删除自己的评论');
        });
        index++;
    }


    // 小图标功能实现
    const dianZan = document.querySelectorAll('.icon-dinazan');
    const shouCang = document.querySelectorAll('.icon-shoucang');
    const article_link = document.querySelectorAll('.title');
    let stuff_num = 0;
    let used1 = [], used2 = [];
    //点赞+收藏
    for (let i = 0; i < dianZan.length; i++) {
        used1[i] = true;
        dianZan[i].addEventListener('click', function () {
            if (used1[i]) {
                if (sessionStorage.getItem('name')) {
                    this.style.color = '#EF6D57';
                    stuff_num = this.nextElementSibling.textContent;
                    this.nextElementSibling.textContent = parseInt(stuff_num) + 1;
                    used1[i] = false;
                } else {
                    alert('请先登录');
                    location.href = 'login.html';

                }
            }
        });
    };
    //设置岗哨使click功能只能点一次
    for (let i = 0; i < dianZan.length; i++) {
        used2[i] = true;
        shouCang[i].addEventListener('click', function () {
            if (used2[i]) {
                if (sessionStorage.getItem('name')) {
                    this.style.color = '#ffa800';
                    stuff_num = this.nextElementSibling.textContent;
                    this.nextElementSibling.textContent = parseInt(stuff_num) + 1;
                    used2[i] = false;
                } else {
                    alert('请先登录');
                    location.href = 'login.html';
                }
            }
        });
    };
});