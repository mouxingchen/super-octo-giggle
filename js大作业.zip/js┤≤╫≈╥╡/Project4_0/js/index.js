window.addEventListener('load', function () {
    // 图片随鼠标动效功能实现
    const cover = document.querySelector('.cover');
    let maxWidth;
    //给图片添加自适应效果
    window.addEventListener('resize', function () {
        maxWidth = window.innerWidth + 'px';
        cover.style.cssText = `max-width:${maxWidth}`;
    });

    const imgBox = document.querySelector('.img-box');
    cover.addEventListener('mousemove', function (e) {
        let boxLeft = cover.offsetLeft;
        let boxTop = cover.offsetTop;
        let x = -(e.clientX - boxLeft) / 10;
        let y = -(e.clientY - boxTop) / 10;
        imgBox.style.transform = `translate3d(${x}px,${y}px,${0}px)`;
    });

    // 小图标功能实现
    const dianZan = document.querySelectorAll('.icon-dinazan');
    const shouCang = document.querySelectorAll('.icon-shoucang');
    const article_link = document.querySelectorAll('.title');
    let stuff_num = 0;
    let used1 = [], used2 = [];
    //点赞+收藏
    for (let i = 0; i < dianZan.length; i++) {
        used1[i] = true;
        dianZan[i].addEventListener('click', function () {
            if (used1[i]) {
                if (sessionStorage.getItem('name')) {
                    this.style.color = '#EF6D57';
                    stuff_num = this.nextElementSibling.textContent;
                    this.nextElementSibling.textContent = parseInt(stuff_num) + 1;
                    used1[i] = false;
                } else {
                    alert('请先登录');
                    location.href = 'login.html';
                    
                }
            }
        });
    };
    //设置岗哨使click功能只能点一次
    for (let i = 0; i < dianZan.length; i++) {
        used2[i] = true;
        shouCang[i].addEventListener('click', function () {
            if (used2[i]) {
                if (sessionStorage.getItem('name')) {
                    this.style.color = '#ffa800';
                    stuff_num = this.nextElementSibling.textContent;
                    this.nextElementSibling.textContent = parseInt(stuff_num) + 1;
                    used2[i] = false;
                } else {
                    alert('请先登录');
                    location.href = 'login.html';
                }
            }
        });
    };

    //scrollReveal功能引入
    var config = {
        reset: true, // 滚动鼠标时，动画开关（如果为true, 动画可以执行n次）
        origin: 'bottom', // 动画开始的方向
        distance: '300px',//移动距离
        duration: 1000, // 动画持续时间
        delay: 0, // 延迟
        rotate: { x: 0, y: 0, z: 0 }, // 过度到0的初始角度，关键点想要酷炫的样式主要修改此参数
        container: document.documentElement,
        opacity: 0, // 初始透明度
        scale: 0.8,
        // viewFactor: 100,//视角，可拉长看到的距离
        // viewOffset: {//可看到的范围，全屏往里缩
        //   top: 150,
        //   right: 0,
        //   bottom: 150,
        //   left: 0
        // },
        // 回调函数
        //当动画开始之前会被触发
        beforeReveal: function (domEl) { },
        //鼠标滚轮滚动之前会被触发
        beforeReset: function (domEl) { },
        //动画开始之后会被触发
        afterReveal: function (domEl) { },
        //滚轮滚动之后会被触发
        afterReset: function (domEl) { }
    };

    //2).然后实例化一个scrollReveal对象
    window.sr = ScrollReveal();

    //3).再调用scrollReveal里的reveal方法将scrollReveal内部的动画和css中的标签关联起来
    const post = document.querySelectorAll('.post');
    for (let i = 2; i < post.length; i++) {
        sr.reveal(post[i], config);
    }
    //参数一：跟html标签关联的类名
    //参数二：动画配置
})