window.addEventListener('load', function () {
    //导航栏功能实现
    const menu = document.querySelector(".menu");
    const nav = document.querySelector('.nav');
    const span = document.querySelectorAll('.menu>span');
    let count = -0;
    menu.addEventListener('click', function (e) {
        e.preventDefault();
        count++;
        if (count % 2) {
            nav.style.top = '0%';
            span[0].style.display = 'none';
            span[1].style.display = 'block';
        } else {
            nav.style.top = '-100%';
            span[0].style.display = 'block';
            span[1].style.display = 'none';
        }
    });

    // 回到顶部实现
    const backtop = document.querySelector('.el-backtop');
    const pointPost = document.querySelector('.post:nth-child(2)');
    window.addEventListener('scroll', function () {
        if (window.pageYOffset >= screen.height/2) {
            backtop.classList.add('apper');
        } else {
            backtop.classList.remove('apper');
        }
    });
    let timer = null;
    backtop.addEventListener('click', function () {
        let num = 10;
        clearInterval(timer);
        timer = setInterval(() => {
            num *= 1.2;
            document.documentElement.scrollTop -= num;
            if (document.documentElement.scrollTop <= 0) {
                clearInterval(timer);
            }
        }, 10);
    });

});